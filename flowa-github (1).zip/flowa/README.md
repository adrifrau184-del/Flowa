# Flowa

Flowa es una primera demo de una red social de fotos con una estética minimalista en blanco y negro.

## Cómo probarla en tu ordenador

1. Descarga y descomprime `flowa-github.zip`.
2. Abre la carpeta `flowa`.
3. Haz doble clic en `index.html` para abrirlo en tu navegador.
4. Prueba el buscador, los likes, los guardados y el formulario para publicar.

> Esta versión es una demo de frontend. Las publicaciones y los likes se guardan en el almacenamiento local de ese navegador; no se comparten con otras personas ni con otros dispositivos. Los perfiles son de ejemplo. No hay todavía registro real, mensajes privados, comentarios reales ni subida de archivos.

## Publicarla gratis en GitHub Pages

1. Crea una cuenta o inicia sesión en https://github.com/
2. Pulsa el botón **+** (arriba a la derecha) y elige **New repository**.
3. Ponle el nombre `flowa`, marca **Public** y pulsa **Create repository**.
4. Dentro del repositorio, pulsa **Add file → Upload files**.
5. Sube los tres archivos `index.html`, `styles.css` y `script.js` (también puedes subir `README.md`).
6. Pulsa **Commit changes** para guardar los archivos.
7. Abre **Settings → Pages**.
8. En **Build and deployment**, elige **Deploy from a branch**.
9. En **Branch**, selecciona `main` y la carpeta `/(root)`, y pulsa **Save**.
10. Espera unos minutos. La página de GitHub Pages mostrará el enlace público de tu web.

Normalmente el enlace tendrá este formato:

`https://TU-USUARIO.github.io/flowa/`

Sustituye `TU-USUARIO` por tu nombre de usuario de GitHub. No es un enlace real hasta que publiques el repositorio.

## Archivos

- `index.html`: estructura de la página.
- `styles.css`: diseño adaptable a ordenador y móvil.
- `script.js`: publicaciones de ejemplo e interacciones.
- `README.md`: estas instrucciones.

## Siguiente paso para convertir Flowa en una red social real

Para tener cuentas reales, publicaciones compartidas entre usuarios y subida de fotos/vídeos, hay que conectar un backend y una base de datos, por ejemplo Supabase o Firebase. GitHub Pages aloja la web estática, pero no ejecuta un servidor backend.
