const profiles = [
  {name:"Mia Santos",handle:"@miasantos",initials:"MS",tone:"#d9d9d9"},
  {name:"Leo Martín",handle:"@leom",initials:"LM",tone:"#bfbfbf"},
  {name:"Noa Vega",handle:"@noavega",initials:"NV",tone:"#e5e5e5"},
  {name:"Alex Ríos",handle:"@alexrios",initials:"AR",tone:"#cfcfcf"},
  {name:"Sara Luna",handle:"@saraluna",initials:"SL",tone:"#ededed"},
  {name:"Dani Cruz",handle:"@danicruz",initials:"DC",tone:"#b8b8b8"}
];

const initialPosts = [
  {id:1,name:"Mia Santos",handle:"@miasantos",initials:"MS",time:"Hace 12 min",caption:"Un poco de calma, buena luz y tiempo para mí. A veces eso es todo lo que hace falta. ✨",image:"https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1200&q=85",likes:128,liked:false,saved:false},
  {id:2,name:"Leo Martín",handle:"@leom",initials:"LM",time:"Hace 34 min",caption:"Persiguiendo nuevos lugares y nuevas ideas. ¿Cuál ha sido vuestro último descubrimiento?",image:"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=85",likes:86,liked:false,saved:false},
  {id:3,name:"Noa Vega",handle:"@noavega",initials:"NV",time:"Hace 1 h",caption:"Menos prisa. Más momentos que merezca la pena recordar. 🖤",image:"https://images.unsplash.com/photo-1518837695005-2083093ee35b?auto=format&fit=crop&w=1200&q=85",likes:204,liked:false,saved:false}
];
let posts = loadPosts();
let currentView = "inicio";
let searchTerm = "";

function loadPosts(){
  try { const saved = JSON.parse(localStorage.getItem("flowa-posts")); return Array.isArray(saved) && saved.length ? saved : initialPosts; }
  catch { return initialPosts; }
}
function persist(){ try { localStorage.setItem("flowa-posts", JSON.stringify(posts)); } catch {} }
function escapeHtml(value){ return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function initials(name){ return name.trim().split(/\s+/).slice(0,2).map(s=>s[0]||"").join("").toUpperCase(); }

function renderStories(){
  document.getElementById("stories").innerHTML = profiles.map(p=>`
    <button class="story" data-profile="${escapeHtml(p.handle)}" aria-label="Ver publicaciones de ${escapeHtml(p.name)}">
      <span class="story-ring"><span class="story-avatar" style="background:${p.tone}">${p.initials}</span></span>
      <span>${escapeHtml(p.name.split(" ")[0])}</span>
    </button>`).join("");
}
function renderSuggestions(){
  document.getElementById("suggestions").innerHTML = profiles.slice(0,4).map((p,i)=>`
    <div class="suggestion"><div class="avatar" style="background:${p.tone};color:#111">${p.initials}</div>
      <div class="suggestion-info"><strong>${escapeHtml(p.name)}</strong><span>${escapeHtml(p.handle)}</span></div>
      <button class="follow-button" data-follow="${escapeHtml(p.handle)}">Seguir</button></div>`).join("");
}
function visiblePosts(){
  let result = [...posts];
  if(currentView === "guardados") result = result.filter(p=>p.saved);
  if(currentView === "perfil") result = result.filter(p=>p.handle === "@tu_usuario");
  if(currentView === "explorar") result.reverse();
  if(searchTerm) result = result.filter(p => `${p.name} ${p.handle} ${p.caption}`.toLowerCase().includes(searchTerm));
  return result;
}
function renderFeed(){
  const feed = document.getElementById("feed"), empty = document.getElementById("empty-state");
  const result = visiblePosts();
  document.getElementById("feed-title").textContent = currentView==="guardados" ? "Tus guardados" : currentView==="perfil" ? "Tus publicaciones" : currentView==="explorar" ? "Explorar" : "Tu feed";
  feed.innerHTML = result.map(p=>{
    const image = p.image && /^https:\/\/|^http:\/\//i.test(p.image);
    return `<article class="post-card">
      <div class="post-top"><div class="avatar">${escapeHtml(p.initials || initials(p.name))}</div>
        <div class="post-user"><strong>${escapeHtml(p.name)}</strong><span>${escapeHtml(p.handle)} · ${escapeHtml(p.time || "Ahora")}</span></div><span class="post-menu">•••</span></div>
      ${image ? `<img class="post-image" src="${escapeHtml(p.image)}" alt="Imagen publicada por ${escapeHtml(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.classList.remove('hidden')"><div class="post-placeholder hidden">FLOWA</div>` : `<div class="post-placeholder">FLOWA</div>`}
      <div class="post-body"><div class="post-actions">
        <button class="action-button ${p.liked?'liked':''}" data-like="${p.id}" aria-label="Me gusta"><span class="heart">${p.liked?'♥':'♡'}</span><span>${p.likes}</span></button>
        <button class="action-button" data-comment="${p.id}" aria-label="Comentar">○<span>Comentar</span></button>
        <button class="action-button bookmark ${p.saved?'liked':''}" data-save="${p.id}" aria-label="Guardar publicación">${p.saved?'◆':'◇'}</button>
      </div><p class="post-caption"><strong>${escapeHtml(p.handle)}</strong>${escapeHtml(p.caption)}</p><div class="post-meta">VER PUBLICACIÓN · COMPARTE BUENA ENERGÍA</div></div>
    </article>`;
  }).join("");
  empty.classList.toggle("hidden", result.length !== 0);
  feed.classList.toggle("hidden", result.length === 0);
}
function toast(message){
  const el=document.getElementById("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2400);
}
function setView(view){
  currentView=view; searchTerm=""; document.getElementById("search-input").value="";
  document.querySelectorAll("[data-view]").forEach(b=>b.classList.toggle("active",b.dataset.view===view));
  document.getElementById("page-title").textContent=({inicio:"Inicio",explorar:"Explorar",guardados:"Guardados",perfil:"Mi perfil"})[view]||"Inicio";
  renderFeed();
  window.scrollTo({top:0,behavior:"smooth"});
}
function openDialog(){document.getElementById("create-dialog").showModal();}
document.addEventListener("click",e=>{
  const view=e.target.closest("[data-view]"); if(view){setView(view.dataset.view);return;}
  const like=e.target.closest("[data-like]");
  if(like){const p=posts.find(x=>x.id===Number(like.dataset.like));if(p){p.liked=!p.liked;p.likes+=p.liked?1:-1;persist();renderFeed();}return;}
  const save=e.target.closest("[data-save]");
  if(save){const p=posts.find(x=>x.id===Number(save.dataset.save));if(p){p.saved=!p.saved;persist();renderFeed();toast(p.saved?"Publicación guardada":"Quitada de guardados");}return;}
  const follow=e.target.closest("[data-follow]");
  if(follow){const active=follow.classList.toggle("following");follow.textContent=active?"Siguiendo":"Seguir";toast(active?"Ahora sigues a este creador":"Has dejado de seguirlo");return;}
  const story=e.target.closest("[data-profile]");
  if(story){document.getElementById("search-input").value=story.dataset.profile;searchTerm=story.dataset.profile.toLowerCase();currentView="inicio";renderFeed();toast("Mostrando publicaciones que coinciden");return;}
  if(e.target.closest("[data-comment]"))toast("Los comentarios se añadirán en la siguiente versión.");
});
["open-create","mobile-create","mobile-nav-create","welcome-create"].forEach(id=>document.getElementById(id)?.addEventListener("click",openDialog));
document.getElementById("close-dialog").addEventListener("click",()=>document.getElementById("create-dialog").close());
document.getElementById("reset-feed").addEventListener("click",()=>setView("inicio"));
document.getElementById("search-input").addEventListener("input",e=>{searchTerm=e.target.value.trim().toLowerCase();renderFeed();});
document.getElementById("create-form").addEventListener("submit",e=>{
  e.preventDefault();
  const name=document.getElementById("post-author").value.trim();
  const caption=document.getElementById("post-caption").value.trim();
  const image=document.getElementById("post-image").value.trim();
  if(!name||!caption){toast("Escribe tu nombre y una descripción.");return;}
  if(image && !/^https?:\/\//i.test(image)){toast("La URL debe empezar por http:// o https://");return;}
  const post={id:Date.now(),name,handle:"@tu_usuario",initials:initials(name),time:"Ahora",caption,image,likes:0,liked:false,saved:false};
  posts.unshift(post);persist();setView("inicio");document.getElementById("create-dialog").close();e.target.reset();renderFeed();toast("¡Tu publicación está en Flowa!");
});
renderStories();renderSuggestions();renderFeed();
